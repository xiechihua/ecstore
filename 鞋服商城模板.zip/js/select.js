
// JavaScript Document
jQuery(function ($) {
   "use strict";
   $("#selectpicker, #selectpickertwo").selectpicker();
   
});